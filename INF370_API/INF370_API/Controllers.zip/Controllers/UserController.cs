﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using INF370_API.Models;
using System.Dynamic;
using System.Web.Cors;
using System.Web;
using INF370_API.ViewModels;
using System.Data.Entity;
using System.Web.Http.Cors;

namespace INF370_API.Controllers
{
   [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class UserController : ApiController
    {

    //    dynamic response = new ExpandoObject();
    //    response.Name = rental.Customer.Name;
    //                response.Cell = rental.Customer.Cell;
    //                response.Email = rental.Customer.Email;
    //                response.RentalID = rental.RentalID;
    //                response.RentalDate = rental.Date;
    //                List<dynamic> TheList = new List<dynamic>();
    //                foreach (var line in rentalLine)
    //                {
    //                    dynamic item = new ExpandoObject();
    //    item.Description = line.Rentable.Description;
    //                    item.PricePerDay = line.Rentable.PricePerDay;
    //                    item.StartDate = line.StartDate;
    //                    item.EndDate = line.EndDate;
    //                    item.Days = line.EndDate - line.StartDate;
    //                    item.LinePrice = item.PricePerDay* item.Days;
    //    TheList.Add(item);
    //                }
    //response.RentalLines = TheList;
        INF370Entities db = new INF370Entities();

        [System.Web.Http.Route("api/User/GetAllUsers")]
        [System.Web.Http.HttpGet]
        public List<dynamic>GetAllUsers()
        {
            db.Configuration.ProxyCreationEnabled = false;
            List<CLIENT> List = new List<CLIENT>();
            List = db.CLIENTs.Include(z => z.USER).ToList();
    
            try
            {
                List<dynamic> ClientList = new List<dynamic>();
                foreach(var x in db.USERs.Include(zz => zz.USERTYPE))
                {
                    dynamic clientUser = new ExpandoObject();
                    //clientUser.UserID = x.USERID;
                    clientUser.Username = x.USERNAME;
                    CLIENT client = db.CLIENTs.Where(zz => zz.USERID == x.USERID).FirstOrDefault();
                    //clientUser.ClientID = client.CLIENTID;
                    clientUser.Name = client.NAME;
                    clientUser.Surname = client.SURNAME;
                    clientUser.PhoneNo = client.PHONENUMBER;
                    clientUser.Email = client.EMAIL;
                    clientUser.UserType = x.USERTYPE.USERTYPEDESCRIPTION;

                    ClientList.Add(clientUser);
                }


                return ClientList;
            }
            catch (Exception)
            {
                throw;
            }
        }




        //List<ClientUser> ClientList = new List<ClientUser>();
        //        foreach(var x in db.USERs)
        //        {
        //            ClientUser clientuser = new ClientUser();
        //clientuser.USERID = x.USERID;
        //            clientuser.Username = x.USERNAME;
        //            clientuser.Password = x.PASSWORD;
        //            clientuser.NAME = x.CLIENT.NAME;
        //            clientuser.SURNAME = x.CLIENT.SURNAME;
        //            clientuser.PHONENUMBER = x.CLIENT.PHONENUMBER;
        //            clientuser.EMAIL = x.CLIENT.EMAIL;
        //            clientuser.PASSPORTNO = x.CLIENT.ID_PASSPORT_NO__;
        //            clientuser.NATIONALITY = x.CLIENT.NATIONALITY;
        //            clientuser.DATE_OF_BIRTH = x.CLIENT.DATE_OF_BIRTH;
        //            clientuser.ISSTUDENT = x.CLIENT.ISSTUDENT;
        //            clientuser.RESIDENTIAL_ADDRESS = x.CLIENT.RESIDENTIAL_ADDRESS;
        //            clientuser.POSTAL_ADDRESS = x.CLIENT.POSTAL_ADDRESS;
        //            clientuser.NAME_OF_EMPLOYER = x.CLIENT.NAME_OF_EMPLOYER;
        //            clientuser.OCCUPATION = x.CLIENT.OCCUPATION;
        //            clientuser.WORK_ADDRESS = x.CLIENT.WORK_ADDRESS;
        //            clientuser.WORK_TEL_NO = x.CLIENT.WORK_TEL__NO;
        //            clientuser.GROSS_SALARY = x.CLIENT.GROSS_SALARY;
        //            ClientList.Add(clientuser);


        [Route("api/User/AddUser")]
        [HttpPost]
        public dynamic AddUser(dynamic myUser)
        {
           

            CLIENT client = new CLIENT();
            USER user = new USER();
            user.USERNAME = myUser.Username;
            //Save to DB
            try
            {

                //user.USERNAME = httpRequest["ProductName"];
                //user.PASSWORD = httpRequest["ProductName"];
                //user.USERTYPEID = 2;

                //client.NAME = httpRequest["ProductName"];
                //client.SURNAME = httpRequest["ProductName"];
                //client.PHONENUMBER = httpRequest["ProductName"];
                //client.EMAIL = httpRequest["ProductName"];
                //client.ID_PASSPORT_NO__ = httpRequest["ProductName"];
                //client.NATIONALITY = httpRequest["ProductName"];
                //client.DATE_OF_BIRTH = httpRequest["ProductName"];
                //client.ISSTUDENT = httpRequest["ProductName"];
                //client.RESIDENTIAL_ADDRESS = httpRequest["ProductName"];
                //client.POSTAL_ADDRESS = httpRequest["ProductName"];
                //client.NAME_OF_EMPLOYER = httpRequest["ProductName"];
                //client.OCCUPATION = httpRequest["ProductName"];
                //client.WORK_ADDRESS = httpRequest["ProductName"];
                //client.WORK_TEL__NO = httpRequest["ProductName"];
                //client.GROSS_SALARY = httpRequest["ProductName"];



            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Error With Product Details");
            }


            try
            {
                db.CLIENTs.Add(client);
                db.SaveChanges();

            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e.Message);
            }

            return Request.CreateResponse(HttpStatusCode.Created);

        }




    }
}
