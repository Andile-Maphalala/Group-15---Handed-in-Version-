﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using INF370_API.Models;
using System.Web.Http.Cors;

namespace INF370_API.Controllers
{
    [RoutePrefix("Api/Employee")]
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    public class EmployeeController : ApiController
    {
        
        INF370Entities db = new INF370Entities();

        [HttpGet]
        [Route("GetEmployeeTypes")]
        public IQueryable<EMPLOYEETYPE> GetEmployeeTypes()
        {
            INF370Entities db = new INF370Entities();
            db.Configuration.ProxyCreationEnabled = false;
            try
            {
                return db.EMPLOYEETYPEs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        [Route("GetEmployeeTypeDetailsById/{EmployeeTypeID}")]
        public IHttpActionResult GetEmployeeTypeById(string EmployeeTypeID)
        {

            db.Configuration.ProxyCreationEnabled = false;

            EMPLOYEETYPE objEmp = new EMPLOYEETYPE();
            int ID = Convert.ToInt32(EmployeeTypeID);
            try
            {
                objEmp = db.EMPLOYEETYPEs.Find(ID);
                if (objEmp == null)
                {
                    return NotFound();
                }

            }
            catch (Exception)
            {
                throw;
            }

            return Ok(objEmp);
        }

        [HttpPost]
        [Route("InsertEmployeeTypeDetails")]
        public IHttpActionResult PostOwner(EMPLOYEETYPE data)
        {
            INF370Entities db = new INF370Entities();
            db.Configuration.ProxyCreationEnabled = false;

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                db.EMPLOYEETYPEs.Add(data);
                db.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }



            return Ok(data);
        }


        [HttpPut]
        [Route("UpdateEmployeeTypeDetails")]
        public IHttpActionResult PutOwnerMaster(EMPLOYEETYPE EmployeeType)
        {

            db.Configuration.ProxyCreationEnabled = false;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                EMPLOYEETYPE objEmp = new EMPLOYEETYPE();
                objEmp = db.EMPLOYEETYPEs.Find(EmployeeType.EMPLOYEETYPEID);
                if (objEmp != null)
                {
                    objEmp.EMPLOYEETYPEDESCRIPTION = EmployeeType.EMPLOYEETYPEDESCRIPTION;
                 


                }
                int i = this.db.SaveChanges();

            }
            catch (Exception)
            {
                throw;
            }
            return Ok(EmployeeType);
        }


        [HttpDelete]
        [Route("DeleteEmployeeTypeDetails")]
        public IHttpActionResult DeleteOwner(int id)
        {
            INF370Entities db = new INF370Entities();
            db.Configuration.ProxyCreationEnabled = false;


            EMPLOYEETYPE employeeTypeDetails = db.EMPLOYEETYPEs.Find(id);
            if (employeeTypeDetails == null)
            {
                return NotFound();
            }

            db.EMPLOYEETYPEs.Remove(employeeTypeDetails);
            db.SaveChanges();

            return Ok(employeeTypeDetails);
        }


    }
}
